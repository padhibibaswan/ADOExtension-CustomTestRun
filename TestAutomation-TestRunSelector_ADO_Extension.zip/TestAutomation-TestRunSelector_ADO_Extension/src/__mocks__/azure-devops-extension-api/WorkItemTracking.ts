/** Needed to not break the mock with AMD related ReferenceError: define is not defined */
export const WorkItemTrackingServiceIds = {
    WorkItemFormService: "ms.vss-work-web.work-item-form"
}
