/**
 * Mocked Helper Function to embed ReactElement in iFrame default document
 */
// tslint:disable-next-line: no-empty
export function showRootComponent(component: React.ReactElement<any>) {}
